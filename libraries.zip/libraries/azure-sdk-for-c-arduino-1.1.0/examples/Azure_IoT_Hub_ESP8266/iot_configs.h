// Copyright (c) Microsoft Corporation. All rights reserved.
// SPDX-License-Identifier: MIT

// Wifi
#define IOT_CONFIG_WIFI_SSID "MyNet"
#define IOT_CONFIG_WIFI_PASSWORD "8080808080"

// Azure IoT
#define IOT_CONFIG_IOTHUB_FQDN "masterthings.azure-devices.net"
#define IOT_CONFIG_DEVICE_ID "Esp8266"
#define IOT_CONFIG_DEVICE_KEY "YaXLIJ0F3SymA/VffFm8Jp/e76eihhS3FAIoTNQe1Z4="

// Publish 1 message every 2 seconds
#define TELEMETRY_FREQUENCY_MILLISECS 2000
